#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <cmath>
#include <iostream>
#include <vector>
#include <sstream>
#include <stdio.h>
#include <iomanip>
#include <stdlib.h>
#include <errno.h>

double gaussian_fun(double x_temp, double delta, double mean);
